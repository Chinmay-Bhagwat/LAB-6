import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shopping-list',
  templateUrl: './shopping-list.component.html',
  styleUrls: ['./shopping-list.component.css']
})
export class ShoppingListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  title = 'Shopping List';
  list:any[]=[];
  addItem (item:string,price:string) {
  this.list.push({id:this.list.length,name:item,price:price})
  console.warn(this.list);
  }
  removeItem (id:number) {
  console.warn(id);
  this.list=this.list.filter(item=>item.id!==id);
  }
}
