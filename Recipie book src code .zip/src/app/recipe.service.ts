import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RecipeService {

  constructor() { }

   getRecipe=()=>{
    return[
      {'id': 1,'name':'Shahi Paneer','ingredient':['Paneer','Nestlé A+ Curd','Onion', 'Cream', 'Almond', 'Coriander Leaves', 'Garam Masala', 'Ginger Garlic Paste',' Dhania Powder', 'Red Chilly'],'image':'../../assets/images/shahi_paneer_featured.jpg'},
      {'id':2,'name':'Upma','ingredient':['Mustard seeds','Cumin seeds','Urad dal','Channa dal','Peanuts','Rava'],'image':'../../assets/images/Upama .jpg'},
      {'id':3,'name':'Besan Chilla','ingredient':['Besan','Ajwain','Salt','Turmeric','Onion','Tomatoes','Green chilli','Coriander leaves'],'image':'../../assets/images/Besan chilla .jpeg'}
    ]
  }
}
