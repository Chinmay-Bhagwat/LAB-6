import { Component, OnInit } from '@angular/core';
import {RecipeService} from '../recipe.service'

@Component({
  selector: 'app-recipe',
  templateUrl: './recipe.component.html',
  styleUrls: ['./recipe.component.css']
})
export class RecipeComponent implements OnInit {

  public recipe : any[] = []
  public recipe2 : any[] = [];
   id : any;
  constructor(private _recipeService : RecipeService) { }

 
  ngOnInit(): void {
    this.recipe = this._recipeService.getRecipe();
    
  }

  display(id2:any){
    this.recipe2 = []
    this.id = id2;
    console.log(id2)
    this.recipe2.push(this.recipe.filter((item)=>{
      return item.id == this.id;
    }))
    console.log(this.recipe2[0][0].name)
    
  }

  check()
  {
    console.log("loaded");
  }
  


}
