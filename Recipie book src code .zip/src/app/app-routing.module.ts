import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {RecipeComponent} from '../app/recipe/recipe.component';
import { ShoppingListComponent } from '../app/shopping-list/shopping-list.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {path:'list',component:ShoppingListComponent},
  { path : 'recipe',component:RecipeComponent},
  { path : 'home',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

